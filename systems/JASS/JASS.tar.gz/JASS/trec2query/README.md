Extracts queries from TREC-style topic files, and optionally stems them with the specified stemmer. Uses the same letters for stemmer as atire does. That is, a `-tp` in atire should be invoked as `-s p` for this version of `trec2query`.

    make ATIRE_DIR=`path to atire`
    ./trec2query
