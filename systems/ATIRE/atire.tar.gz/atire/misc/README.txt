#######################################################
#													  #
# INFORMATION REGARDING FILES WITHIN THIS DIRECTORY   #
#													  #
#		Please do not delete these files			  #
#													  #
#######################################################


1. ant_style.xml is the ECLIPSE ANT code style file

2. ANT_coding_convention.txt is the 10 rules of ANT coding convention