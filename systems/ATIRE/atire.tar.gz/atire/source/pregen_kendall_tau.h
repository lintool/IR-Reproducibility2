/*
	PREGEN_KENDALL_TAU.H
	--------------------
*/
#ifndef PREGEN_KENDALL_TAU_H_
#define PREGEN_KENDALL_TAU_H_

#include "pregen.h"

double ANT_kendall_tau(std::pair<ANT_pregen_t, ANT_pregen_t> *docs, int doc_count);

#endif /* PREGEN_KENDALL_TAU_H_ */

