/*
	READABILITY_NONE.H
	------------------
*/

#ifndef READABILITY_NONE_H_
#define READABILITY_NONE_H_

/*
	class READABILITY_NONE
	----------------------
*/
class ANT_readability_none : public ANT_readability
{
};

#endif  /* READABILITY_NONE_H_ */
