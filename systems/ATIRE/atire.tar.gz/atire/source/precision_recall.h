/*
	PRECISION_RECALL.H
	------------------
*/
#ifndef PRECISION_RECALL_H_
#define PRECISION_RECALL_H_

/*
	class ANT_PRECISION_RECALL
	--------------------------
*/
class ANT_precision_recall
{
public:
	double precision;
	double recall;
} ;

#endif /* PRECISION_RECALL_H_ */
