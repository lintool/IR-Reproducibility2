/*
	ENCODE_CHAR.H
	-------------
*/
#ifndef ENCODE_CHAR_H_
#define ENCODE_CHAR_H_

#define CHAR_ENCODE_FAIL 255

#endif /* ENCODE_CHAR_H_ */
