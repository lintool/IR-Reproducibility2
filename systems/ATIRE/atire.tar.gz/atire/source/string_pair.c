#include "string_pair.h"

#ifdef COUNT_STRCMP_CALLS
unsigned long long ANT_string_pair::strcmp_calls = 0;
#endif
