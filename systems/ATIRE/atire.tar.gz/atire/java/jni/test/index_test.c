#include "index.h"

int main(int argc, char **argv) {
return atire_index(argv[1]);
}
