/*
 * atire.h
 *
 *  Created on: 22/10/2013
 *      Author: monfee
 */

#ifndef ATIRE_H_
#define ATIRE_H_


extern int run_atire(char *options);


#endif /* ATIRE_H_ */
