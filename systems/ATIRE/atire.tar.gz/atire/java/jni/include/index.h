/*
 * index.h
 *
 */

#ifndef INDEX_H_
#define INDEX_H_

//#ifdef __cplusplus
//extern "C" {
//#endif

extern int atire_index(char *options);
//extern FILE *atire_output;

//#ifdef __cplusplus
//}
//#endif

#endif /* INDEX_H_ */
