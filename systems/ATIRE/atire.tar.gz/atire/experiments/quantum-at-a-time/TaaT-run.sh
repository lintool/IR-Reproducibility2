#! /bin/bash

$HOME/source-devel/hg/atire/experiments/quantum-at-a-time/run.sh TaaT