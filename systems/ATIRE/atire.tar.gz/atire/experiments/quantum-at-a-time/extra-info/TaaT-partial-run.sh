#! /bin/bash

$HOME/source-devel/hg/atire/experiments/quantum-at-a-time/extra-info/run.sh TaaT-partial