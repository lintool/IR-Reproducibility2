/*
 * system_info.cpp
 *
 *  Created on: Aug 3, 2009
 *      Author: monfee
 */

#include "system_info.h"

system_info::system_info() {
	// TODO Auto-generated constructor stub

}

system_info::~system_info() {
	// TODO Auto-generated destructor stub
}
