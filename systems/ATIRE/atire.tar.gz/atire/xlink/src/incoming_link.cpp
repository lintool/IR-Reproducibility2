/*
 * incoming_link.cpp
 *
 *  Created on: Aug 3, 2009
 *      Author: monfee
 */

#include "incoming_link.h"
#include "ant_link_term.h"
#include "ant_link_posting.h"

#include <string.h>

using namespace QLINK;

incoming_link::incoming_link() {

}

incoming_link::~incoming_link() {

}

