/*
 * wikipedia_page.cpp
 *
 *  Created on: Mar 22, 2011
 *      Author: monfee
 */

#include "wikipedia_page.h"

namespace QLINK
{

wikipedia_page::wikipedia_page()
{

}

wikipedia_page::~wikipedia_page()
{

}

bool is_century(const char *term)
{
	return false;
}

bool is_year(const char *term)
{
	return false;
}

bool is_number(const char *term)
{
	return false;
}

}
