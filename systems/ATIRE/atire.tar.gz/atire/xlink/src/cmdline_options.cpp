/*
 * cmdline_options.cpp
 *
 *  Created on: Aug 11, 2009
 *      Author: monfee
 */

#include "cmdline_options.h"

int cmdline_options::argc = 0;
char **cmdline_options::argv = 0;

cmdline_options::cmdline_options()
{

}

cmdline_options::~cmdline_options()
{
}
