/*
 * outgoing_link.cpp
 *
 *  Created on: Aug 3, 2009
 *      Author: monfee
 */

#include "outgoing_link.h"
#include "ant_link_term.h"
#include "ant_link_posting.h"

#include <string.h>

using namespace QLINK;


outgoing_link::outgoing_link() {

}

outgoing_link::~outgoing_link() {

}

