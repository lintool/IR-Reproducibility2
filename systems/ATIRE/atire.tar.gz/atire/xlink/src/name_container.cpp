/*
 * name_container.cpp
 *
 *  Created on: Sep 30, 2009
 *      Author: monfee
 */

#include "name_container.h"

using namespace QLINK;

name_container::name_container()
{

}

name_container::~name_container()
{

}

void name_container::init()
{

}
