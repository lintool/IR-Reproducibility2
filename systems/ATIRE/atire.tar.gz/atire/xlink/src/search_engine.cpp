/*
 * search_engine.cpp
 *
 *  Created on: Sep 30, 2009
 *      Author: monfee
 */

#include "search_engine.h"

search_engine::search_engine()
{
	hits_ = 0;
	docids_ = 0;
}

search_engine::~search_engine()
{

}
