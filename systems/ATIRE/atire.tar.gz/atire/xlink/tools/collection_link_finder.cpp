/*
 * collection_link_finder.cpp
 *
 *  Created on: Nov 10, 2009
 *      Author: monfee
 */

int main(int argc, char **argv)
{
	return 1;
}
