#!/bin/bash

./ltw -noyears -runname:code-f -targets:1 -anchors:250 -index /data/corpus/inex/2009/ltw/index/links-a.idx /data/corpus/inex/2009/ltw/2009_33Topics/12578.xml > 12578.linked
