#!/bin/bash

export CFLAGS="-g -DDEBUG"
export CXXFLAGS="-g -DDEBUG"
