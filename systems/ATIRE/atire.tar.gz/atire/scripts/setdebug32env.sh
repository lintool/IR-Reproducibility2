#!/bin/bash

export CFLAGS="-g -m32 -DDEBUG"
export CXXFLAGS="-g -m32 -DDEBUG"
